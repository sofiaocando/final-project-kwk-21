//
//  journalingVC.swift
//  FinalProject
//
//  Created by Scholar on 8/4/21.
//

import UIKit

class journalingVC: UIViewController {
    @IBOutlet weak var entryOutlet: UITextView!
    @IBOutlet weak var entryOutputOutlet: UITextView!
    
    var previousEntries : [PreviousEntriesCD] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        if let accessToCoreData = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext {

        if let dataFromCoreData = try? accessToCoreData.fetch(PreviousEntriesCD.fetchRequest()) as? [PreviousEntriesCD] {
           previousEntries = dataFromCoreData
            previousEntries.sav
             }
        }
        
            
    }
    @IBAction func submitTapped(_ sender: Any) {
        //entryOutputOutlet.text.append(entryOutlet.text)
        
        
        guard let accessToCoreData = UIApplication.shared.delegate as? AppDelegate else {
            return
            }

       //this line stores the information from Core Data into the object (dataFromCoreData) that we can access.
            let dataFromCoreData = accessToCoreData.persistentContainer.viewContext

       //this line creates an empty object that is the same data type as the ToDoCD entry within Core Data.  This means this object will have all the properties of ToDoCD.
            let newEntry = PreviousEntriesCD(context: dataFromCoreData)

       //these lines give the object information from the user input
            newEntry.savedEntriesInCD = entryOutputOutlet.text

       //This is like clicking "save"! Our new object is now safe in Core Data!
            accessToCoreData.saveContext()

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
